"use client";

import { useState } from "react";
import { Copy, Download, FileText, Check } from "lucide-react";

interface OutputViewerProps {
  payload: string;
  tokensUsed?: number;
  durationMs?: number;
  model?: string;
  isStreaming?: boolean;
}

function scorePrompt(text: string): { score: number; label: string; color: string } {
  let score = 0;
  const sections = ["ROLE", "ARCHITECTURE", "STACK", "API", "DATABASE", "COMPONENT", "DEPLOY", "TEST", "SECURITY", "ERROR"];
  for (const s of sections) {
    if (text.toUpperCase().includes(s)) score += 10;
  }
  if (text.length > 5000) score += 10;
  if (text.length > 12000) score += 10;
  const capped = Math.min(score, 100);
  let label = "Developing";
  let color = "#F59E0B";
  if (capped >= 80) { label = "Enterprise-Grade"; color = "#10B981"; }
  else if (capped >= 60) { label = "Production-Ready"; color = "#06B6D4"; }
  else if (capped >= 40) { label = "Functional"; color = "#F59E0B"; }
  return { score: capped, label, color };
}

export default function OutputViewer({ payload, tokensUsed, durationMs, model, isStreaming }: OutputViewerProps) {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try { await navigator.clipboard.writeText(payload); } catch {
      const el = document.createElement("textarea");
      el.value = payload;
      document.body.appendChild(el);
      el.select();
      document.execCommand("copy");
      document.body.removeChild(el);
    }
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const downloadFile = (ext: string) => {
    const type = ext === "md" ? "text/markdown" : "text/plain";
    const blob = new Blob([payload], { type });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `mpa-prompt-${Date.now()}.${ext}`;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (!payload && !isStreaming) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center gap-3 py-8 px-4">
        <FileText size={32} className="text-gray-700" />
        <p className="text-gray-500 text-sm">Generated prompts will appear here</p>
        <p className="text-gray-700 text-xs">Use the chat or click Generate</p>
      </div>
    );
  }

  const words = payload.trim().split(/\s+/).filter(Boolean).length;
  const quality = payload.length > 100 ? scorePrompt(payload) : null;

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center justify-between gap-2 px-4 py-3 border-b border-white/10 bg-[#111] shrink-0 flex-wrap">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-emerald-400 text-xs font-mono uppercase tracking-widest flex items-center gap-2">
            Enterprise Prompt
            {isStreaming && <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />}
          </span>
          {(tokensUsed ?? 0) > 0 && (
            <span className="text-gray-600 text-xs font-mono">
              {tokensUsed?.toLocaleString()} tokens
              {durationMs !== undefined && ` · ${(durationMs / 1000).toFixed(1)}s`}
              {model && ` · ${model.split("-").slice(0, 2).join("-")}`}
            </span>
          )}
        </div>
        <div className="flex gap-1.5">
          <button onClick={() => downloadFile("txt")} className="text-xs font-mono px-2 py-1 rounded-lg bg-[#1a1a1a] text-gray-400 hover:text-white border border-white/5 transition-colors">
            .txt
          </button>
          <button onClick={() => downloadFile("md")} className="text-xs font-mono px-2 py-1 rounded-lg bg-[#1a1a1a] text-gray-400 hover:text-white border border-white/5 transition-colors">
            .md
          </button>
          <button
            onClick={handleCopy}
            className="flex items-center gap-1 text-xs font-mono px-3 py-1 rounded-lg bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20 border border-emerald-500/20 transition-colors font-semibold"
          >
            {copied ? <Check size={10} /> : <Copy size={10} />}
            {copied ? "Copied!" : "Copy"}
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="px-4 pt-3 flex items-center gap-3 flex-wrap shrink-0">
        {payload.length > 0 && (
          <>
            <span className="text-gray-600 text-xs font-mono">{payload.length.toLocaleString()} chars</span>
            <span className="text-gray-700 text-xs">·</span>
            <span className="text-gray-600 text-xs font-mono">{words.toLocaleString()} words</span>
          </>
        )}
        {quality && (
          <>
            <span className="text-gray-700 text-xs">·</span>
            <span className="text-xs font-mono">
              <span className="text-gray-500">Quality: </span>
              <span style={{ color: quality.color }} className="font-semibold">{quality.label}</span>
              <span className="text-gray-600"> ({quality.score}/100)</span>
            </span>
          </>
        )}
      </div>

      {/* Content */}
      <div className="flex-1 overflow-auto p-4">
        <pre className="bg-[#0a0a0a] rounded-xl px-4 py-4 text-emerald-400 text-xs font-mono leading-relaxed whitespace-pre-wrap break-words border border-white/5">
          {payload}
          {isStreaming && !payload && <span className="text-cyan-400 animate-pulse">▋</span>}
        </pre>
      </div>

      {payload && !isStreaming && (
        <div className="px-4 pb-3 shrink-0">
          <p className="text-gray-700 text-[10px] font-mono text-center">
            Paste this prompt in Replit, Cursor, or any AI coding tool to build the described application.
          </p>
        </div>
      )}
    </div>
  );
}
