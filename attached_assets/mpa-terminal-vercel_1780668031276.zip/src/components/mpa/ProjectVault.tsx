"use client";

import { useState } from "react";
import { Save, FolderOpen, Trash2 } from "lucide-react";

export interface SavedProject {
  id: string;
  label: string;
  entity: string;
  context: string;
  masterObjective: string;
  protocol: string;
  createdAt: number;
}

interface ProjectVaultProps {
  projects: SavedProject[];
  onSave: (label: string) => void;
  onLoad: (project: SavedProject) => void;
  onDelete: (id: string) => void;
  currentEntity: string;
}

export default function ProjectVault({ projects, onSave, onLoad, onDelete, currentEntity }: ProjectVaultProps) {
  const [label, setLabel] = useState("");

  return (
    <div className="bg-[#111] rounded-xl border border-white/5 overflow-hidden">
      <div className="flex items-center gap-2 px-4 py-3 border-b border-white/5">
        <FolderOpen size={12} className="text-emerald-400" />
        <p className="text-white text-xs font-medium">Project Vault</p>
        {projects.length > 0 && <span className="text-gray-600 text-[10px] font-mono">({projects.length})</span>}
      </div>
      <div className="p-4">
        <div className="flex gap-2">
          <input
            type="text"
            value={label}
            onChange={(e) => setLabel(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter") { onSave(label); setLabel(""); } }}
            placeholder="Project name (optional)"
            className="flex-1 bg-[#0a0a0a] border border-white/10 text-white placeholder:text-gray-600 focus:border-emerald-500/40 outline-none rounded-lg px-3 py-2 text-[10px] font-mono"
          />
          <button
            onClick={() => { onSave(label); setLabel(""); }}
            disabled={!currentEntity.trim()}
            className="flex items-center gap-1 text-[10px] font-mono px-3 py-2 rounded-lg bg-[#1a1a1a] text-gray-400 hover:text-white border border-white/5 disabled:opacity-40 transition-all"
          >
            <Save size={10} /> Save
          </button>
        </div>
        {projects.length > 0 ? (
          <div className="mt-3 space-y-1.5 max-h-40 overflow-y-auto">
            {projects.map((p) => (
              <div key={p.id} className="flex items-center gap-2 bg-[#0a0a0a] rounded-lg px-3 py-2 border border-white/5">
                <button onClick={() => onLoad(p)} className="flex-1 text-left min-w-0">
                  <p className="text-white text-[10px] font-medium truncate hover:text-emerald-400 transition-colors">{p.label}</p>
                  <p className="text-gray-600 text-[10px] font-mono mt-0.5">{new Date(p.createdAt).toLocaleDateString()} · {p.protocol}</p>
                </button>
                <button onClick={() => onDelete(p.id)} className="text-gray-700 hover:text-red-400 transition-colors shrink-0">
                  <Trash2 size={10} />
                </button>
              </div>
            ))}
          </div>
        ) : (
          <p className="mt-3 text-gray-700 text-[10px] font-mono text-center py-3">
            No saved projects yet
          </p>
        )}
      </div>
    </div>
  );
}
