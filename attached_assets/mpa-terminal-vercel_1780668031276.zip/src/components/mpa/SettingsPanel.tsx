"use client";

import { Eye, EyeOff, Key, Zap, Thermometer } from "lucide-react";
import { DOMINANCE_PROTOCOLS, AI_MODELS } from "@/lib/mpa/templates";

interface SettingsPanelProps {
  apiKey: string;
  setApiKey: (v: string) => void;
  apiProvider: string;
  setApiProvider: (v: string) => void;
  model: string;
  setModel: (v: string) => void;
  masterObjective: string;
  setMasterObjective: (v: string) => void;
  targetEntity: string;
  setTargetEntity: (v: string) => void;
  targetContext: string;
  setTargetContext: (v: string) => void;
  protocol: string;
  setProtocol: (v: string) => void;
  customDirectives: string;
  setCustomDirectives: (v: string) => void;
  temperature: number;
  setTemperature: (v: number) => void;
  showKey: boolean;
  setShowKey: (v: string) => void;
  onGenerate: () => void;
  isLoading: boolean;
  canGenerate: boolean;
}

const INPUT_CLASS =
  "w-full bg-[#0a0a0a] border border-white/10 text-white placeholder:text-gray-600 focus:border-emerald-500/40 outline-none transition-all rounded-xl px-3 py-2.5 text-xs font-mono";

export default function SettingsPanel({
  apiKey, setApiKey, apiProvider, setApiProvider, model, setModel,
  masterObjective, setMasterObjective, targetEntity, setTargetEntity,
  targetContext, setTargetContext, protocol, setProtocol,
  customDirectives, setCustomDirectives, temperature, setTemperature,
  showKey, setShowKey, onGenerate, isLoading, canGenerate,
}: SettingsPanelProps) {
  const selectedProto = DOMINANCE_PROTOCOLS.find((p) => p.id === protocol);
  const filteredModels = AI_MODELS.filter((m) => m.provider === apiProvider);

  return (
    <div className="space-y-4">
      {/* API Provider */}
      <div className="bg-[#111] rounded-xl border border-white/5 p-4 space-y-3">
        <div className="flex items-center gap-2">
          <Zap size={12} className="text-emerald-400" />
          <p className="text-white text-xs font-medium tracking-wide">AI Provider</p>
        </div>
        <div className="flex gap-1 p-1 bg-[#0a0a0a] rounded-lg">
          <button
            onClick={() => { setApiProvider("groq"); setModel("llama3-70b-8192"); }}
            className={`flex-1 text-xs font-mono px-3 py-2 rounded-lg transition-all ${
              apiProvider === "groq" ? "bg-cyan-500/20 text-cyan-400" : "text-gray-500 hover:text-white"
            }`}
          >
            Groq (Free)
          </button>
          <button
            onClick={() => { setApiProvider("openai"); setModel("gpt-4o-mini"); }}
            className={`flex-1 text-xs font-mono px-3 py-2 rounded-lg transition-all ${
              apiProvider === "openai" ? "bg-emerald-500/20 text-emerald-400" : "text-gray-500 hover:text-white"
            }`}
          >
            OpenAI
          </button>
        </div>

        <div>
          <div className="flex items-center justify-between mb-1.5">
            <p className="text-gray-400 text-[10px] font-mono uppercase tracking-widest">
              {apiProvider === "groq" ? "Groq API Key" : "OpenAI API Key"}
            </p>
            <button onClick={() => setShowKey(!showKey)} className="text-gray-500 hover:text-white transition-colors">
              {showKey ? <EyeOff size={12} /> : <Eye size={12} />}
            </button>
          </div>
          <div className="relative">
            <input
              type={showKey ? "text" : "password"}
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
              placeholder={apiProvider === "groq" ? "gsk_..." : "sk-..."}
              className={INPUT_CLASS + " pr-10"}
            />
            <Key size={12} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-600" />
          </div>
          <p className="text-gray-700 text-[10px] mt-1 font-mono">
            {apiProvider === "groq"
              ? "Get a free key at console.groq.com — also auto-reads GROQ_API_KEY env var"
              : "Set OPENAI_API_KEY in Vercel env vars, or enter it above"}
          </p>
        </div>
      </div>

      {/* Model */}
      <div className="bg-[#111] rounded-xl border border-white/5 p-4">
        <p className="text-gray-400 text-[10px] font-mono uppercase tracking-widest mb-2">Model</p>
        <div className="flex gap-1 flex-wrap">
          {filteredModels.map((m) => (
            <button
              key={m.id}
              onClick={() => setModel(m.id)}
              className={`text-xs font-mono px-2.5 py-1.5 rounded-lg transition-all ${
                model === m.id
                  ? apiProvider === "groq" ? "bg-cyan-500/20 text-cyan-400" : "bg-emerald-500/20 text-emerald-400"
                  : "bg-[#0a0a0a] text-gray-500 hover:text-white"
              }`}
            >
              {m.label} <span className="opacity-50">{m.speed}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Project Config */}
      <div className="bg-[#111] rounded-xl border border-white/5 p-4 space-y-3">
        <p className="text-gray-400 text-[10px] font-mono uppercase tracking-widest">Project Configuration</p>
        <div>
          <p className="text-white text-xs font-medium mb-1.5">Master Objective</p>
          <textarea
            value={masterObjective}
            onChange={(e) => setMasterObjective(e.target.value)}
            placeholder="e.g., 'I am building MPD, a private AI website builder…'"
            rows={2}
            className={INPUT_CLASS + " resize-y"}
          />
        </div>
        <div>
          <p className="text-white text-xs font-medium mb-1.5">Target Entity</p>
          <input
            type="text"
            value={targetEntity}
            onChange={(e) => setTargetEntity(e.target.value)}
            placeholder="e.g., Fleet Management E-commerce"
            className={INPUT_CLASS}
          />
        </div>
        <div>
          <p className="text-white text-xs font-medium mb-1.5">Target Context / URL</p>
          <textarea
            value={targetContext}
            onChange={(e) => setTargetContext(e.target.value)}
            placeholder="Describe the target architecture or paste a URL…"
            rows={2}
            className={INPUT_CLASS + " resize-y"}
          />
        </div>
        <div>
          <p className="text-white text-xs font-medium mb-1.5">Dominance Protocol</p>
          <select
            value={protocol}
            onChange={(e) => setProtocol(e.target.value)}
            className={INPUT_CLASS + " appearance-none cursor-pointer"}
          >
            {DOMINANCE_PROTOCOLS.map((p) => (
              <option key={p.id} value={p.id} className="bg-[#111]">{p.label}</option>
            ))}
          </select>
          {selectedProto && <p className="text-gray-600 text-[10px] mt-1 font-mono">{selectedProto.description}</p>}
        </div>
        <div>
          <p className="text-white text-xs font-medium mb-1.5">Custom Directives <span className="text-gray-600 font-normal">(optional)</span></p>
          <textarea
            value={customDirectives}
            onChange={(e) => setCustomDirectives(e.target.value)}
            placeholder="e.g., 'Use Tailwind v4', 'Avoid Redux'"
            rows={2}
            className={INPUT_CLASS + " resize-y"}
          />
        </div>
      </div>

      {/* Temperature */}
      <div className="bg-[#111] rounded-xl border border-white/5 p-4">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <Thermometer size={12} className="text-emerald-400" />
            <p className="text-white text-xs font-medium">Creativity</p>
          </div>
          <span className="text-gray-400 text-xs font-mono">{temperature.toFixed(1)}</span>
        </div>
        <input
          type="range"
          min={0.1}
          max={1.0}
          step={0.1}
          value={temperature}
          onChange={(e) => setTemperature(parseFloat(e.target.value))}
          className="w-full h-1 accent-emerald-500"
        />
        <div className="flex justify-between mt-1">
          <span className="text-gray-600 text-[10px] font-mono">Precise</span>
          <span className="text-gray-600 text-[10px] font-mono">Creative</span>
        </div>
      </div>

      {/* Generate Button */}
      <button
        onClick={onGenerate}
        disabled={!canGenerate || isLoading}
        className={`w-full font-semibold text-sm py-3.5 rounded-xl transition-all text-white ${
          isLoading
            ? "bg-emerald-500/30 cursor-wait"
            : canGenerate
              ? "bg-emerald-500 hover:bg-emerald-400 active:scale-[0.98]"
              : "bg-gray-800 cursor-not-allowed opacity-40"
        }`}
      >
        {isLoading ? (
          <span className="flex items-center justify-center gap-2">
            <span className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            Streaming…
          </span>
        ) : (
          "Generate MACH Enterprise Prompt"
        )}
      </button>

      {!canGenerate && !isLoading && (
        <p className="text-center text-gray-600 text-[10px] font-mono">
          Fill Target Entity + Context to enable generation
        </p>
      )}
    </div>
  );
}
